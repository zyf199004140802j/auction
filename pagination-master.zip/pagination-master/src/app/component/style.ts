export const Style = {
    "position": ["absolute", "fixed", "relative", "static", "inherit"],
    "display": ["none", "block", "inline", "inline-block", "list-item", "table"],
    "disabled": [true, false],
}

