export enum TypeId {
    LABEL = 0,
    BUTTON = 1,
    AlERT = 2,
    ICON = 3,
    LIST = 4,
}