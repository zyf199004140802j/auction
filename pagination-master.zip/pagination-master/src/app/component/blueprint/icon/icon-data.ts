export const ICONDATA: IconData[] = [
    { id: 1, image: '../../../assets/images/3.jpg', description: 'THIS IS A PICTURE' },
    { id: 2, image: '../../../assets/images/0.jpg', description: 'THIS IS A PICTURE' },
    { id: 3, image: '../../../assets/images/4.jpg', description: 'THIS IS A PICTURE' }
];
export class IconData {
    public id: number;
    public image: string;
    public description: string;
}
