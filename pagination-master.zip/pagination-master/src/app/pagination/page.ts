export class Page {
    id: number;
    name: string;
    age: number;
}