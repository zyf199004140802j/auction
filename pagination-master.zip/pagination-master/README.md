# Angular-4-pagination

此项目是在angular 2+ 环境上搭建的；

自定义的分页组件

但因这上传的是测试案例，所以数据都是取得本地数据

但本人已经在项目中使用过

其中还借助了ng2-bootstrap框架来使页面变得好看点。

运行地址：
https://sulishibaobei.github.io/pagination/dist/index.html

